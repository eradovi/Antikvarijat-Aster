import re
def zadatak_1():

    with open('radovic_emma_virtualna_stvarnost.txt','r', encoding="utf8") as file:
        citaj = file.read()

        lista_rijeci = citaj.split()
        broj_rijeci = len(lista_rijeci)
        print("Ukupan broj riječi u seminaru je: ", broj_rijeci)

zadatak_1()


def zadatak_2():
        
    with open('radovic_emma_virtualna_stvarnost.txt','r', encoding="utf8") as file:
        citaj = file.read()

        rijec_kao = len(re.findall(r'\bkao', citaj, re.IGNORECASE))
        print(f"Broj puta kada se spominje riječ 'kao' u tekstu seminara: {rijec_kao}")

zadatak_2()

def zadatak_3():
        
    with open('radovic_emma_virtualna_stvarnost.txt','r', encoding="utf8") as file:
        citaj = file.read()

        interpunkcijski_znakovi = len(re.findall(r'[\(\)\.\!\?\,\;\:\–\-\„\“\'\'\/\"\.{3}]', citaj))
        print(f"Broj interpunkcijskih znakova (točka (.), uskličnik (!), upitnik (?), zarez (,), točka sa zarezom (;), dvotočje (:), "
              f"crtica (–), spojnica (-), tri točke (…), navodnici („“, ''), kosa crta (/) i"
              f"zagrade()) u seminaru je: {interpunkcijski_znakovi}")

zadatak_3()

def zadatak_4():
    with open('radovic_emma_virtualna_stvarnost.txt','r', encoding="utf8") as file:
        citaj = file.read()

        broj_rijeci_koje_pocinju_s_a = len(re.findall(r'\ba', citaj,re.IGNORECASE))
        print(f"Broj riječi koje počinju posljednjim slovom imena Emma (slovo a): {broj_rijeci_koje_pocinju_s_a}")

zadatak_4()

def zadatak_5():
    
    with open('radovic_emma_virtualna_stvarnost.txt','r', encoding="utf8") as file:
        citaj = file.read()

        broj_rijeci_koje_zavrsavaju_s_r = len(re.findall(r'\b\w*r\b', citaj,re.IGNORECASE))
        print(f"Broj riječi koje završavaju prvim slovom prezimena Radović (slovo r): {broj_rijeci_koje_zavrsavaju_s_r}")

zadatak_5()