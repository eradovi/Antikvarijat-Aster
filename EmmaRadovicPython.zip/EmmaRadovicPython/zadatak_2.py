import csv

def ucitavanje(datoteka):
    with open(datoteka,'r') as file:
        citaj = csv.reader(file, delimiter=';')

        zaglavlje = next(citaj)

        podaci = []

        for row in citaj:
            if len(row) >= 4:
                    podaci.append([int(vrijednost) if vrijednost.isdigit() else 0 for vrijednost in row[1:]])
            else:
                 continue

    return podaci

def harmonijska_sredina(vrij_):
    return len(vrij_) / sum(1 / vrijednost for vrijednost in vrij_ if vrijednost != 0)

def analiza(vrij_):

    prave_vrijednosti = [vrijednost for vrijednost in vrij_ if vrijednost != 0]

    sortirane_vrijednosti = sorted(prave_vrijednosti)
    n = len(prave_vrijednosti)

    kvartil_1 = sortirane_vrijednosti[int(n * 0.25)]

    if n % 2 == 0:
        medijan = (sortirane_vrijednosti[n // 2 - 1] + sortirane_vrijednosti[n // 2]) / 2
    else:
        medijan = sortirane_vrijednosti[n // 2]

    mean = sum(prave_vrijednosti) / n
    varijanca = sum((x - mean) ** 2 for x in prave_vrijednosti) / n

    min_vrijednost = min(sortirane_vrijednosti)
    max_vrijednost = max(sortirane_vrijednosti)

    return kvartil_1, medijan, varijanca, min_vrijednost, max_vrijednost

def main():
    datoteka = 'DE PP0701_HR.csv'
    podaci = ucitavanje(datoteka)
    
    stupac_godina = [0, 1, 2]
    for i, indeks_godine in enumerate(stupac_godina):
            podaci_godine = [row[indeks_godine] for row in podaci]
            print(f"\nAnaliza za {2021 + i} godinu:")

            podaci_godine = [vrijednost for vrijednost in podaci_godine if isinstance(vrijednost, int)]
            suma = sum(podaci_godine)
            harmonijska = harmonijska_sredina(podaci_godine)
            kvartil_1, medijan, varijanca, min_vrijednost, max_vrijednost = analiza(podaci_godine)
            print(f"Suma: {suma}\nHarmonijska sredina: {harmonijska:.2f}\n1. kvartil: {kvartil_1}\nMedijan: {medijan}\nVarijanca: {varijanca:.2f}\nMinimum: {min_vrijednost}\nMaksimum: {max_vrijednost}")    

main()